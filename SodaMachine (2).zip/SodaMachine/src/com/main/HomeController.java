package com.main;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HomeController {

	@Autowired
	private MachineService service;
	

	@RequestMapping("/")
	public String home(HttpSession session, HttpServletRequest request) {
		return "index";
	}
	
	@RequestMapping("/main")
	public String main(HttpSession session, HttpServletRequest request) {
		int value = Integer.parseInt(request.getParameter("newPrice"));
		int value2 = Integer.parseInt(request.getParameter("newAmount"));
		service.setPrice(value);
		service.addBottles(value2);
		session.setAttribute("price", service.getPrice());
		session.setAttribute("coins_Inserted", service.getCoinsInserted());
		session.setAttribute("status", service.checkStatus());
		session.setAttribute("bottlesRemaining", service.getBottlesRemaining());
		return "home";
	}
	
	@RequestMapping("/addBottles")
	public String addBottles(HttpSession session, HttpServletRequest request) {
		int value = Integer.parseInt(request.getParameter("add"));
		service.addBottles(value);
		session.setAttribute("bottlesRemaining", service.getBottlesRemaining());
		session.setAttribute("status", service.checkStatus().toString());
		return "home";
	}
	
	@RequestMapping("/insertCoin")
	public String insertCoin(HttpSession session) {
		service.insertCoin();
		session.setAttribute("coins_Inserted", service.getCoinsInserted());
		session.setAttribute("status", service.checkStatus().toString());
		return "home";
	}
	
	@RequestMapping("/removeCoin")
	public String removeCoin(HttpSession session) {
		service.removeCoin();
		session.setAttribute("coins_Inserted", service.getCoinsInserted());
		session.setAttribute("status", service.checkStatus().toString());
		return "home";
	}
	
	@RequestMapping("/buySoda")
	public String buySoda(HttpSession session) {
		service.buySoda();
		session.setAttribute("coins_Inserted", service.getCoinsInserted());
		session.setAttribute("status", service.checkStatus().toString());
		session.setAttribute("bottlesRemaining", service.getBottlesRemaining());
		return "home";
	}
	
	@RequestMapping("/dispenseSoda")
	public String dispenseSoda(HttpSession session) {
		service.dispenseSoda();
		session.setAttribute("status", service.checkStatus().toString());
		session.setAttribute("bottlesRemaining", service.getBottlesRemaining());
		return "home";
	}
	@RequestMapping("/displayHistory")
	public String displayHistory(Model model) {
		model.addAttribute("lists", service.getBoughtTimestamps());
		return "home";
	}
	
}
