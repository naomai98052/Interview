package com.main;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class MachineServiceImpl implements MachineService {

	States state;
	private int bottlesRemaining;
	private int coinsInserted = 0;
	private int price;
	private boolean bought = false;
	private List<String> boughtTimestamps = new LinkedList<String>();


	public void setPrice(int price) {
		this.price = price;
	}

	public void addBottles(int addition) {
		bottlesRemaining+= addition;
	}


	public List<String> getBoughtTimestamps() {
		return boughtTimestamps;
	}


	public void insertCoin() {
		if(state != States.SOLDOUT) {
			++coinsInserted;
		}
	}


	public void removeCoin() {
		if(coinsInserted>0) {
			--coinsInserted;
		}
	}


	public void buySoda() {
		if(bought){
			System.out.println("You have already bought a bottle.");
			return;
		}
		if(bottlesRemaining == 0) {
			checkStatus();
			return;
		}
		if(coinsInserted >= price) {
				coinsInserted-=price;
				System.out.println("Purchased soda, coins remaining is: " + coinsInserted);
				bought = true;
				--bottlesRemaining;
				boughtTimestamps.add(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		}else {
			System.out.println("You need " + (price-coinsInserted) + " more coins.");
		}
	}

	public void dispenseSoda() {
		if(bought){
			System.out.println("Soda dispensed.");
			bought = false;
		}
	}
	
	public States checkStatus() {
		if(bottlesRemaining == 0 && !bought) {
			return States.SOLDOUT;
		}
		if(bought) {
			return States.SOLD;
		} else if(coinsInserted > 0) {
			return States.HAS_QUARTER;
		} else {
			return States.NO_QUARTER;
		}
	}

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//getters and setters below
	
	public int getBottlesRemaining() {
		return bottlesRemaining;
	}

	public int getCoinsInserted() {
		return coinsInserted;
	}

	public int getPrice() {
		return price;
	}

	public boolean isBought() {
		return bought;
	}

	public void setBoughtTimestamps(List<String> boughtTimestamps) {
		this.boughtTimestamps = boughtTimestamps;
	}

}
