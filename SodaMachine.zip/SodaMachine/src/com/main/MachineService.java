package com.main;

import java.util.List;

public interface MachineService {
	public enum States {
		NO_QUARTER,
		HAS_QUARTER,
		SOLD,
		SOLDOUT
	}
	public void setPrice(int price);
	public void addBottles(int addition);
	public List<String> getBoughtTimestamps();
	public void insertCoin();
	public void removeCoin();
	public void buySoda();
	public void dispenseSoda();
	public int getBottlesRemaining();
	public int getCoinsInserted();
	public int getPrice();
	public boolean isBought();
	public void setBoughtTimestamps(List<String> boughtTimestamps);
	public States checkStatus();
}
