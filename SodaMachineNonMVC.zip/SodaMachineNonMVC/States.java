package com.main;

public enum States {
	NO_QUARTER,
	HAS_QUARTER,
	SOLD,
	SOLDOUT
}
