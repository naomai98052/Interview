import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class VendingMachine {
	States state;
	int price;
	int bottlesRemaining = 0;
	int coinsInserted = 0;
	boolean bought = false;
	List<String> boughtTimestamps = new LinkedList<String>();
	
	public VendingMachine(int price, int bottlesRemaining) {
		this.price = price;
		this.bottlesRemaining = bottlesRemaining;
		if(bottlesRemaining <= 0) {
			state = States.SOLDOUT;
		}else {
			state = States.NO_QUARTER;
		}
	}
	public static void main(String[] args) {
		int x=0, y=0;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("enter the price of the bottle: ");
		while(!scan.hasNextInt()) scan.next();
		x = scan.nextInt();
		
		System.out.println();
		
		System.out.print("enter the initial amount of bottles in machine: ");
		while(!scan.hasNextInt()) scan.next();
		y = scan.nextInt();
		VendingMachine temp = new VendingMachine(x, y);
		
		while(true) {
			System.out.println();
			System.out.println("State: " + temp.state + ", Bottles Remaining = " + temp.bottlesRemaining + ", price = " + temp.price + ", coins inserted = " + temp.coinsInserted + ".");
			System.out.println("Enter I to insert coin, R to remove coin, B to buy soda, D to dispense, A to add bottles to machine, H to report purchase history");
			String next = scan.next();
			switch(next) {
				case "I": temp.insertCoin();break;
				case "R": temp.removeCoin();break;
				case "B": temp.buySoda();break;
				case "D": temp.dispenseSoda();break;
				case "H": temp.getReport();break;
				case "A": {
					System.out.println();
					System.out.println("type in amount to add:");
					while(!scan.hasNextInt()) scan.next();
					int value = scan.nextInt();
					temp.addBottles(value);
				}
			}
		}
	}
	
	public void insertCoin() {
		if(state != States.SOLDOUT) {
		++coinsInserted;
		}
		checkStatus();
	}
	public void removeCoin() {
		if(coinsInserted>0) {
			--coinsInserted;
		}
		checkStatus();
	}
	public void buySoda() {
		if(bought) {
			System.out.println("You have already bought a bottle.");
			return;
		}
		if(bottlesRemaining == 0) {
			checkStatus();
			return;
		}
		if(coinsInserted >= price) {
				coinsInserted-=price;
				System.out.println("Purchased soda, coins remaining is: " + coinsInserted);
				bought = true;
				--bottlesRemaining;
				boughtTimestamps.add(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()));
		}else {
			System.out.println("You need " + (price-coinsInserted) + " more coins.");
		}
		checkStatus();
	}
	
	public void dispenseSoda() {
		if(bought) {
				System.out.println("Soda dispensed.");
				bought = false;
		}
		checkStatus();
	}
	
	public void addBottles(int add) {
		bottlesRemaining += add;
		checkStatus();
	}
	
	public void getReport() {
		System.out.println(boughtTimestamps.toString());
	}
	
	public void checkStatus() {
		if(bottlesRemaining == 0 && !bought) {
			state = States.SOLDOUT;
			System.out.println("No more bottles in vending machine, please add.");
			return;
		}
		if(bought) {
			state = States.SOLD;
			System.out.println("You have purchased a bottle, please dispense.");
		} else if(coinsInserted > 0) {
			state = States.HAS_QUARTER;
			System.out.println("Please add more coins or buy a bottle.");
		} else {
			state = States.NO_QUARTER;
			System.out.println("Available to buy. Please add coins.");
		}
	}
	
	
}
